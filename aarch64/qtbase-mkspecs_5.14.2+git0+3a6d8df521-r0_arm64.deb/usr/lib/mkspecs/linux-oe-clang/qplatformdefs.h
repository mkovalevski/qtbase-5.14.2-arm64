#include "../linux-clang/qplatformdefs.h"
